package com.example.pocket_app_valedosol.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.pocket_app_valedosol.model.ServiceEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ServiceDao {

    @Query("SELECT * FROM services ORDER BY name ASC")
    fun getAllServices(): Flow<List<ServiceEntity>>

    @Query(
        "SELECT * FROM services " +
                "WHERE name LIKE '%' || :query || '%' " +
                "ORDER BY name ASC"
    )
    fun searchServices(query: String): Flow<List<ServiceEntity>>

    @Query("SELECT * FROM services WHERE id = :id")
    fun getById(id: Int): Flow<ServiceEntity?>

    @Insert
    suspend fun insert(service: ServiceEntity)
}
