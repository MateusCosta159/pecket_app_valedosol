package com.example.pocket_app_valedosol

import android.R.attr.category
import android.content.Intent
import android.net.Uri

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.pocket_app_valedosol.databinding.ActivityDetailBinding
import androidx.core.net.toUri

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Recupera os dados passados da MainActivity
        val name = intent.getStringExtra("SERVICE_NAME") ?: "Nome não disponível"
        val category = intent.getStringExtra("SERVICE_CATEGORY") ?: "Categoria não disponível"
        val description = intent.getStringExtra("SERVICE_DESCRIPTION") ?: "Descrição não disponível"
        val phone = intent.getStringExtra("SERVICE_PHONE") ?: ""
        val website = intent.getStringExtra("SERVICE_WEBSITE") ?: ""
        val address = intent.getStringExtra("SERVICE_ADDRESS") ?: ""
        val imageResId = intent.getIntExtra("SERVICE_IMAGE", R.drawable.costureira)

        // Configura os dados na tela
        setupViews(name, category, description, imageResId)

        // Configura os botões
        setupClickListeners(name, description, phone, website, address)
    }

    private fun setupViews(name: String, category: String, description: String, imageResId: Int) {
        // DEBUG: Verifique se os dados estão chegando
        println("DEBUG - Name: $name")
        println("DEBUG - Category: $category")
        println("DEBUG - Description: $description")
        println("DEBUG - Image ID: $imageResId")

        binding.detailImageView.setImageResource(imageResId)
        binding.detailNameTextView.text = name
        binding.detailCategoryTextView.text = category
        binding.detailDescriptionTextView.text = description
    }

    private fun setupClickListeners(name: String, description: String, phone: String, website: String, address: String) {
        // Botão de Ligação
        binding.callButton.setOnClickListener {
            if (phone.isNotEmpty()) {
                val intent = Intent(Intent.ACTION_DIAL).apply {
                    data = "tel:$phone".toUri()
                }
                startActivity(intent)
            }
        }

        // Botão de Website
        binding.websiteButton.setOnClickListener {
            if (website.isNotEmpty()) {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    data = website.toUri()
                }
                startActivity(intent)
            }
        }

        // Botão de Maps
        binding.mapsButton.setOnClickListener {
            if (address.isNotEmpty()) {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    data = "geo:0,0?q=${Uri.encode(address)}".toUri()
                }
                startActivity(intent)
            }
        }

        // Botão de Compartilhar
        binding.shareButton.setOnClickListener {
            val shareText = """
                $name
                $category
                
                $description
                
                📞 Telephone: $phone
                📍 Render: $address
                🌐 Site: $website
            """.trimIndent()

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            startActivity(Intent.createChooser(intent, getString(R.string.share_service)))
        }
    }
}