package com.example.pocket_app_valedosol.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.pocket_app_valedosol.R
import com.example.pocket_app_valedosol.databinding.ItemServiceBinding
import com.example.pocket_app_valedosol.model.ServiceEntity

class ServiceAdapter(
    private var items: List<ServiceEntity>,
    private val onClick: (ServiceEntity) -> Unit
) : RecyclerView.Adapter<ServiceAdapter.ViewHolder>() {

    fun update(newList: List<ServiceEntity>) {
        items = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemServiceBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(items[position])
    }

    inner class ViewHolder(private val binding: ItemServiceBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(service: ServiceEntity) {
            binding.serviceNameTextView.text = service.name
            binding.serviceCategoryTextView.text = service.category

            Glide.with(binding.root)
                .load(service.imageUri)
                .placeholder(R.drawable.placeholder)
                .into(binding.serviceImageView)

            binding.root.setOnClickListener {
                onClick(service)
            }
        }
    }
}
