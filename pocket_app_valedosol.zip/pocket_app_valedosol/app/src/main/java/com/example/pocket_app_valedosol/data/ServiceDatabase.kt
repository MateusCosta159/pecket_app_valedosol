package com.example.pocket_app_valedosol.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.pocket_app_valedosol.model.ServiceEntity

@Database(entities = [ServiceEntity::class], version = 1, exportSchema = false)
abstract class ServiceDatabase : RoomDatabase() {

    abstract fun serviceDao(): ServiceDao

    companion object {
        @Volatile
        private var INSTANCE: ServiceDatabase? = null

        fun getDatabase(context: Context): ServiceDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ServiceDatabase::class.java,
                    "service_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
