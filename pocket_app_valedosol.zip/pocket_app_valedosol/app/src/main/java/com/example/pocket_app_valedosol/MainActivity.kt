package com.example.pocket_app_valedosol

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.pocket_app_valedosol.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var serviceAdapter: ServiceAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupServicesList()
    }

    private fun setupServicesList() {
        val services = listOf(
            Service(
                id = 1,
                name = getString(R.string.costureira_abelhinha),
                category = getString(R.string.category_seamstress),
                description = getString(R.string.costureira_desc),
                phone = "+5516997045107",
                website = "https://www.instagram.com/abelhinhauniformes",
                address = "Av. Carlos de Angeli, 175 - Parque Res. Vale do Sol, Araraquara - SP",
                imageResId = R.drawable.costureira
            ),
            Service(
                id = 2,
                name = getString(R.string.mercado_real),
                category = getString(R.string.category_market),
                description = getString(R.string.mercado_desc),
                phone = "+551633317071",
                website = "https://www.instagram.com/supermercadosreal_loja2/",
                address = "R. Benedito Garcia Leal, 115 - Parque Res. Vale do Sol, Araraquara - SP",
                imageResId = R.drawable.mercado
            ),
            Service(
                id = 3,
                name = getString(R.string.oficina_moto_center),
                category = getString(R.string.category_workshop),
                description = getString(R.string.oficina_desc),
                phone = "+551633352805",
                website = "https://www.instagram.com/moto_center_moto_pecas/",
                address = "R. Bento Aranha do Amaral, 159 - Parque Res. Vale do Sol, Araraquara - SP",
                imageResId = R.drawable.oficina
            ),
            Service(
                id = 4,
                name = getString(R.string.barbearia_bm),
                category = getString(R.string.category_barbershop),
                description = getString(R.string.barbearia_desc),
                phone = "+5516997679975",
                website = "https://www.instagram.com/brenomoreiratattoo/",
                address = "R. Heitor de Nuevo Campos, 158 - Vale do Sol, Araraquara - SP",
                imageResId = R.drawable.barbearia
            ),
            Service(
                id = 5,
                name = getString(R.string.padaria_vale_sol),
                category = getString(R.string.category_bakery),
                description = getString(R.string.padaria_desc),
                phone = "+551633362926",
                website = "https://www.facebook.com/panificadora.valedosol/",
                address = "R. Atílio Jurisato, 110 - Parque Res. Vale do Sol, Araraquara - SP",
                imageResId = R.drawable.padaria
            ),
            Service(
                id = 6,
                name = getString(R.string.lanchonete_fabinho),
                category = getString(R.string.category_snack_bar),
                description = getString(R.string.lanchonete_desc),
                phone = "+551633351826",
                website = "https://www.instagram.com/fabiinho_lanches/",
                address = "Av. Antônio Honorio Real, 159 - Parque Res. Vale do Sol, Araraquara - SP",
                imageResId = R.drawable.lanchonete
            )
        )

        serviceAdapter = ServiceAdapter(services)
        binding.servicesListView.adapter = serviceAdapter

        binding.servicesListView.setOnItemClickListener { _, _, position, _ ->
            val service = services[position]
            val intent = Intent(this, DetailActivity::class.java).apply {
                // Passa cada campo individualmente - MAIS SEGURO
                putExtra("SERVICE_NAME", service.name)
                putExtra("SERVICE_CATEGORY", service.category)
                putExtra("SERVICE_DESCRIPTION", service.description)
                putExtra("SERVICE_PHONE", service.phone)
                putExtra("SERVICE_WEBSITE", service.website)
                putExtra("SERVICE_ADDRESS", service.address)
                putExtra("SERVICE_IMAGE", service.imageResId)
            }
            startActivity(intent)
        }
    }
}