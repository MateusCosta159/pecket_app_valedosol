package com.example.pocket_app_valedosol.ui

import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.pocket_app_valedosol.data.ServiceDatabase
import com.example.pocket_app_valedosol.data.ServiceRepository
import com.example.pocket_app_valedosol.databinding.ActivityCadastroBinding
import com.example.pocket_app_valedosol.model.ServiceEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding
    private lateinit var repository: ServiceRepository
    private var imageUri: String = ""

    private val imagePicker =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                imageUri = it.toString()
                binding.imagePreview.setImageURI(it)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = ServiceRepository(
            ServiceDatabase.getDatabase(this).serviceDao()
        )

        binding.btnSelectImage.setOnClickListener {
            imagePicker.launch("image/*")
        }

        binding.btnSave.setOnClickListener {
            saveService()
        }
    }

    private fun saveService() {
        val service = ServiceEntity(
            name = binding.editName.text.toString(),
            category = binding.editCategory.text.toString(),
            description = binding.editDescription.text.toString(),
            phone = binding.editPhone.text.toString(),
            website = binding.editWebsite.text.toString(),
            address = binding.editAddress.text.toString(),
            imageUri = imageUri
        )

        lifecycleScope.launch(Dispatchers.IO) {
            repository.insert(service)
            withContext(Dispatchers.Main) {
                finish()
            }
        }
    }
}
