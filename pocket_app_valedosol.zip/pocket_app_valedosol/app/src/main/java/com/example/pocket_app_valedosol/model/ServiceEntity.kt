package com.example.pocket_app_valedosol.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "services")
data class ServiceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val category: String,
    val description: String,
    val phone: String,
    val website: String,
    val address: String,
    val imageUri: String
)
