package com.example.pocket_app_valedosol.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.pocket_app_valedosol.adapter.ServiceAdapter
import com.example.pocket_app_valedosol.data.ServiceDatabase
import com.example.pocket_app_valedosol.data.ServiceRepository
import com.example.pocket_app_valedosol.databinding.ActivityMainBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ServiceAdapter
    private lateinit var repository: ServiceRepository
    private var searchJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = ServiceRepository(
            ServiceDatabase.getDatabase(this).serviceDao()
        )

        setupRecycler()
        observeAllServices()
        setupSearch()

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, CadastroActivity::class.java))
        }
    }

    private fun setupRecycler() {
        adapter = ServiceAdapter(emptyList()) {
            startActivity(
                Intent(this, DetailActivity::class.java)
                    .putExtra("SERVICE_ID", it.id)
            )
        }

        binding.servicesRecyclerView.layoutManager =
            LinearLayoutManager(this)
        binding.servicesRecyclerView.adapter = adapter
    }

    private fun observeAllServices() {
        lifecycleScope.launch {
            repository.getAllServices()
                .collectLatest {
                    adapter.update(it)
                }
        }
    }

    private fun setupSearch() {
        binding.searchEditText.addTextChangedListener { text ->
            searchJob?.cancel()
            searchJob = lifecycleScope.launch {
                val query = text.toString()
                val flow = if (query.isBlank())
                    repository.getAllServices()
                else
                    repository.searchServices(query)

                flow.collectLatest {
                    adapter.update(it)
                }
            }
        }
    }
}
