package com.example.pocket_app_valedosol

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import com.example.pocket_app_valedosol.databinding.ItemServiceBinding

class ServiceAdapter(private val services: List<Service>) : BaseAdapter() {

    override fun getCount(): Int = services.size

    override fun getItem(position: Int): Service = services[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val binding = if (convertView == null) {
            ItemServiceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        } else {
            ItemServiceBinding.bind(convertView)
        }

        val service = getItem(position)

        binding.serviceImageView.setImageResource(service.imageResId)
        binding.serviceNameTextView.text = service.name
        binding.serviceCategoryTextView.text = service.category

        return binding.root
    }
}