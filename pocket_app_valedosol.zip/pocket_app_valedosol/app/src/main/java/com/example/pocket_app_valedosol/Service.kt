package com.example.pocket_app_valedosol



import java.io.Serializable

data class Service(
    val id: Int,
    val name: String,
    val category: String,
    val description: String,
    val phone: String,
    val website: String,
    val address: String,
    val imageResId: Int
) : Serializable