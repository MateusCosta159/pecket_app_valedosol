package com.example.pocket_app_valedosol.data

import com.example.pocket_app_valedosol.model.ServiceEntity
import kotlinx.coroutines.flow.Flow

class ServiceRepository(private val dao: ServiceDao) {

    fun getAllServices(): Flow<List<ServiceEntity>> =
        dao.getAllServices()

    fun searchServices(query: String): Flow<List<ServiceEntity>> =
        dao.searchServices(query)

    fun getById(id: Int): Flow<ServiceEntity?> =
        dao.getById(id)

    suspend fun insert(service: ServiceEntity) =
        dao.insert(service)
}
