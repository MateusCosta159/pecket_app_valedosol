package com.example.pocket_app_valedosol.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.pocket_app_valedosol.R
import com.example.pocket_app_valedosol.data.ServiceDatabase
import com.example.pocket_app_valedosol.data.ServiceRepository
import com.example.pocket_app_valedosol.databinding.ActivityDetailBinding
import com.example.pocket_app_valedosol.model.ServiceEntity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var repository: ServiceRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = ServiceRepository(
            ServiceDatabase.getDatabase(this).serviceDao()
        )

        val serviceId = intent.getIntExtra("SERVICE_ID", -1)
        if (serviceId != -1) {
            observeService(serviceId)
        }
    }

    private fun observeService(serviceId: Int) {
        lifecycleScope.launch {
            repository.getById(serviceId).collectLatest { service ->
                service?.let {
                    displayServiceDetails(it)
                }
            }
        }
    }

    private fun displayServiceDetails(service: ServiceEntity) {

        if (service.imageUri.isNotEmpty()) {
            Glide.with(this)
                .load(Uri.parse(service.imageUri))
                .placeholder(R.drawable.placeholder)
                .into(binding.detailImageView)
        } else {
            binding.detailImageView.setImageResource(R.drawable.placeholder)
        }

        binding.detailNameTextView.text = service.name
        binding.detailCategoryTextView.text = service.category
        binding.detailDescriptionTextView.text = service.description

        setupClickListeners(service)
    }

    private fun setupClickListeners(service: ServiceEntity) {

        binding.callButton.setOnClickListener {
            startActivity(
                Intent(Intent.ACTION_DIAL).apply {
                    data = Uri.parse("tel:${service.phone}")
                }
            )
        }

        binding.websiteButton.setOnClickListener {
            startActivity(
                Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse(service.website)
                }
            )
        }

        binding.mapsButton.setOnClickListener {
            startActivity(
                Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("geo:0,0?q=${Uri.encode(service.address)}")
                }
            )
        }

        binding.shareButton.setOnClickListener {
            val shareText = """
                ${service.name}
                ${service.category}
                
                ${service.description}
                
                📞 ${service.phone}
                📍 ${service.address}
                🌐 ${service.website}
            """.trimIndent()

            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, shareText)
                    },
                    getString(R.string.share_service)
                )
            )
        }
    }
}
